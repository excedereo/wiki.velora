---
title: "Крафты"
desc: ""
order: 1
icon: /assets/minecraft/crafting_table2.png
headerHeight: 220
headerFit: cover
headerPos: center
---
