---
title: "Мифический катализатор" 
desc: ""
order: 1
icon: /assets/items/mythic_catalyst/icon.png
headerFit: cover     # cover | contain
headerPos: center    # center/top/bottom/left/right (можно "top center")
headerHeight: 260px  # опционально
hideTitle: true
---


```image
src: /assets/items/mythic_catalyst/craft.png
align: center
width: 40%
```
<div style="text-align:center">
Рецепт крафта Мифического Катализатора
</div>

```callout
type: note
title: См. Также
icon: /assets/icons/idea.png
[[page:fishki/crafts/plates|Крафт Пластин]]
```