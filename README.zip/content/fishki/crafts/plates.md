---
title: "Пластины" 
desc: ""
order: 1
headerFit: cover     # cover | contain
headerPos: center    # center/top/bottom/left/right (можно "top center")
headerHeight: 260px  # опционально
hideTitle: true
---

```image
src: /assets/items/plate/iron_plate_craft.png
align: center
width: 40%
```
<div style="text-align:center">
Рецепт крафта Железной пластины
</div>

<br>

```image
src: /assets/items/plate/netherite_plate_craft.png
align: center
width: 40%
```
<div style="text-align:center">
Рецепт крафта Незеритовой пластины
</div>